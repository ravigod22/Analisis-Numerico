def mostrarMatriz(matriz,orden):
	for i in range(0,orden):
		linea = "| "
		for j in range(orden+1):
			linea +=  str(matriz[i][j])+" "
		linea += "| "
		print(linea)	
			
matriz = [[1,1,1,1,2], [8,4,2,1,6], [3,2,1,0,5], [12,2,0,0,-6]]
orden=len(matriz) 
mostrarMatriz(matriz,orden);    
for j in range(0,orden+1):
	for i in range(0, orden):
		if i>j:
			division=matriz[i][j]/matriz[j][j]
			for k in range(0, orden+1):
				matriz[i][k]=matriz[i][k]-division*matriz[j][k];
x = [0,0,0,0]
for i in range(orden,0,-1):
	suma=0
	for j in range(i,orden):
		suma=suma+matriz[i-1][j]*x[j]
	x[i-1]=((matriz[i-1][orden]-suma)/matriz[i-1][i-1])	
for i in range(0,orden):
	print("x"+str(i)+" = "+str(x[i]))
