import numpy as np
from numpy import linalg as LA

def positiva_definida(x):
    return np.all(np.linalg.eigvals(x) > 0)

def descenso_rapido(A, b, x):
    if (positiva_definida(A) == False) | (A != A.T).any():
        raise ValueError(
            '')
        print("")
    r = b - A @ x
    k = 0
    print("\nValores de 'x' en la iteración:\n")
    iteracion = 1
    while LA.norm(r) > 1e-10:
        p = r
        q = A @ p
        alpha = (p @ r) / (p @ q)
        x = x + alpha * p
        r = r - alpha * q
        k = + 1

        print(" {}: ".format(iteracion), end=" ")
        print(x, " Error: ", LA.norm(r), end="\n")
        iteracion += 1

    return x


A = np.array([[3.0, -1.0, 1.0], [-1.0, 3.0, -1.0], [1.0, -1.0, 3.0]])
b = np.array([-1.0, 7.0, -7.0])

x_0 = np.array([0.0, 0.0, 0.0])

x_f = descenso_rapido(A, b, x = x_0)

print("\n\nResultado final:  {}".format(x_f))
