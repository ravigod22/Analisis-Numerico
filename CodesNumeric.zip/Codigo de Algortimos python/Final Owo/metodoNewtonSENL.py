import math
import numpy as np

TOL = 1e-6
maxIt = 100
n = 3

def f(v):
    x,y,z = v
    f1 = x*y - z**2 - 1
    f2 = x*y*z - x**2 + y**2 - 2
    f3 = np.exp(x) - np.exp(y) + z - 3
    return np.array([f1, f2, f3], dtype = 'f4')

def Jf(v):
    x,y,z = v
    J = np.zeros((n,n), dtype = 'f4')
    J[0] = np.array([y, x, -2*z])
    J[1] = np.array([y*z - 2*x, x*z + 2*y, x*y])
    J[2] = np.array([np.exp(x), -np.exp(y), 1])
    return(J)

def metNewtonENL(x):
    k = 0
    e = 1
    print("--------------------------METODO DE NEWTON (ENL)--------------------------")
    print(" k  |       x        |       y       |       z       |   Errror |f(x)|_2 ")
    print("----+----------------+---------------+---------------+--------------------")
    datos = np.array([k, x[0], x[1], x[2], e])
    print("{} | {:13.10f}  | {:13.10f} | {:13.10f} | {:13.15f}  ".format(*datos))

    k = 1
    while(e > TOL):
        x_ant = x
        h = np.linalg.lstsq(Jf(x), -f(x), rcond = None)[0]
        #print("h = ",h)
        x = np.add(x_ant,h)
        e = np.linalg.norm(f(x), ord = 2)
        datos = np.array([k, x[0], x[1], x[2],  e])
        print("{} | {:13.10f}  | {:13.10f} | {:13.10f} | {:13.15f}  ".format(*datos))
        k+=1

    print("\n=> Solucion: x =", x)
    print("f(x) =",f(x))

#--------------------------------------
x = np.array([0,0,1], dtype = 'f4')
n = len(x)

metNewtonENL(x)
aux = np.array([1.7776719180107405499159549245637,1.4239605978884890880290410180788, 1.2374711177317033717819050711785])
print("f(x) =",f(aux))
