import sympy as sp

x = sp.symbols('x')
def PolinomioTaylor(funcion, x_0, n): # orden = n
    p_x = 0
    for k in range(n+1):
        f_k = funcion.diff(x, k).subs(x, x_0)
        print(f"f^({k}) = {funcion.diff(x, k)} \t f^({k}) ({x_0}) = {f_k}")
        p_x += (f_k/sp.factorial(k)) * (x - x_0)**k
    return p_x

# ----------------------------------------------------------
f = (3+x)**(1/2)
polinomio = PolinomioTaylor(f, 1, 4)
print("Polinomio de Taylor: \n p(x) =", polinomio)