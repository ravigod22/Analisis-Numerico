import math
import numpy as np

TOL = 1e-5
maxIt = 100
n = 2

def f(v):
    x,y = v
    f1 = x*y - 72
    f2 = (x+2)*(y-3) - 72
    return np.array([f1, f2], dtype = 'f4')

def Jf(v):
    x,y = v
    J = np.zeros((n,n), dtype = 'f4')
    J[0] = np.array([y, x])
    J[1] = np.array([y-3, x+2])
    return(J)

def metNewtonENL(x):
    k = 0
    e = 1
    print("------------------METODO DE NEWTON (ENL)-----------------")
    print(" k  |       x        |       y       |   Errror |f(x)|_2 ")
    print("----+----------------+---------------+-------------------")
    datos = np.array([k, x[0], x[1], e])
    print("{} | {:13.10f}  | {:13.10f} | {:13.15f}  ".format(*datos))

    k = 1
    while(e > TOL and k < maxIt):
        x_ant = x
        h = np.linalg.solve(Jf(x), -f(x))

        x = np.add(x_ant,h)
        e = np.linalg.norm(f(x), ord = 2)
        datos = np.array([k, x[0], x[1], e])
        print("{} | {:13.10f}  | {:13.10f} | {:13.15f}  ".format(*datos))
        k+=1

    print("\n=> Solucion: x = {:13.10f}".format(*x))

#--------------------------------------
x = np.array([3,6], dtype = 'f4')
n = len(x)
metNewtonENL(x)