import sympy as sp
import numpy as np

def theta(k):
    pol = 1
    for i in range (k):
        pol *= (x - px[i])  
    return (pol)

def diferencias_divididas():
    tabla = np.zeros((n, n))

    # Llenar la primera columna de la tabla con los valores y
    tabla[:, 0] = py

    # Calcular las diferencias divididas
    for j in range(1, n):
        for i in range(n - j):
            tabla[i, j] = (tabla[i+1, j-1] - tabla[i, j-1]) / (px[i+j] - px[i])
    return (tabla)

def polinomio_newton():
    coef = tabla[0, :]
    pol = 0
    for i in range (1,n):
        pol += coef[i] * theta(i)
    return (pol)


# ---------------------------------------------------
puntos = [(3, 1), (1, -3), (5, 2), (6, 4)]
n = len(puntos)
x = sp.symbols('x')

px = [par[0] for par in puntos]
py = [par[1] for par in puntos]

tabla = diferencias_divididas()
print(tabla)

pol_int = polinomio_newton()

