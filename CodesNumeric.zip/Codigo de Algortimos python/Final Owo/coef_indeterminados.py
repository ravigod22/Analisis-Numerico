import numpy as np

puntos = [(-1, 2), (0, 1), (-2, 3), (1,0)]
n = len(puntos)

px = [par[0] for par in puntos]
py = [par[1] for par in puntos]

A = np.vander(px, increasing=True)

coef_x = np.linalg.solve(A,py)

print("Vector x => ", px)
print("Vector y => ", py)
print("Matriz de Vandermonde:\n", A)

print("\nCoeficientes => ", coef_x)