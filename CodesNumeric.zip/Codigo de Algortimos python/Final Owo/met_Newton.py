import sympy as sp
import numpy as np

    
puntos = [(3, 1), (1, -3), (5, 2), (6, 4)]
n = len(puntos)
x = sp.symbols('x')

px = [par[0] for par in puntos]
py = [par[1] for par in puntos]

def theta(t, k):
    sa = 1
    for i in range (k):
        sa *= (t - px[i])  
    return (sa)

def theta2(k):
    pol = 1
    for i in range (k):
        pol *= (x - px[i])  
    return (pol)

matrix = np.zeros((n,n))
for i in range(n):
    for j in range(i + 1):
        matrix[i][j] = theta(px[i], j)
print(matrix)


coef = np.linalg.solve(matrix, py)
print(coef)

for i in range (n):
    if (i == 0): 
        pol_int = coef[i] * theta2(i)
        continue
    pol_int = sp.Add(pol_int,coef[i] * theta2(i))