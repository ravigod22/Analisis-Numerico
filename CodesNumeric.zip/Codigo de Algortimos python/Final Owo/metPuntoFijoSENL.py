import numpy as np

TOL = 1e-5
maxIt = 100
n = None

def G(x):
    x1,x2,x3 = x
    g1 = np.cos(x2*x3) / 3 + 1/6
    g2 = np.sqrt(x1*x1 + np.sin(x3) + 1.06) / 9 - 0.1
    g3 = -np.exp(-x1*x2) / 20 - (10 * np.pi - 3) / 60
    return(np.array([g1,g2,g3], dtype = 'f4'))

def metPuntoFijo(x):
    k = 0
    e = 1
    print("----------------------METODO DEL PUNTO FIJO (SENL)------------------------")
    print(" k  |       x        |       y       |       z       |   ||x_kk - x_k|| ")
    print("----+----------------+---------------+---------------+--------------------")
    datos = np.array([k, x[0], x[1],x[2]])
    print("{} | {:13.10f}  | {:13.10f} | {:13.10f} |      -------  ".format(*datos))

    k = 1
    while(e > TOL and k < maxIt):
        x_ant = x
        x = G(x)
        e = np.linalg.norm(x - x_ant, ord = np.inf) # norma inf
        datos = np.array([k, x[0], x[1], x[2], e])
        print("{} | {:13.10f}  | {:13.10f} | {:13.10f} | {:13.15f}  ".format(*datos))
        k+=1

    print("\n=> Solucion: x = ", x)

#--------------------------------------
x = np.array([0.1, 0.1, -0.1], dtype = 'f4')
n = len(x)
metPuntoFijo(x)
