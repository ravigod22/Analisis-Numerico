import math
import numpy as np

TOL = 1e-6
maxIt = 100
n = 3

def f(v):
    x,y,z = v
    f1 = x*y - z**2 - 1
    f2 = x*y*z - x**2 + y**2 - 2
    f3 = np.exp(x) - np.exp(y) + z - 3
    return np.array([f1, f2, f3], dtype = 'f4')

def Jf(v):
    x,y,z = v
    J = np.zeros((n,n), dtype = 'f4')
    J[0] = np.array([y, x, -2*z])
    J[1] = np.array([y*z - 2*x, x*z + 2*y, x*y])
    J[2] = np.array([np.exp(x), -np.exp(y), 1])
    return(J)

def metNewtonENL(x):
    k = 0
    e = 1
    print("--------------------------------------------------METODO DE NEWTON (ENL)---------------------------------------------------")
    print(" k  |       h_1      |       h_2     |       h_3     |       x_1      |       x_2     |       x_3     |   Errror |h(k)|_2 ")
    print("----+----------------+---------------+---------------+----------------+---------------+---------------+---------------------")
    datos = np.array([k, x[0], x[1], x[2], e])
    print("{} |       ----     |       ----    |       ----    | {:13.8f}  | {:13.8f} | {:13.8f} |        -----".format(*datos))

    k = 1
    while(e > TOL):
        x_ant = x
        h = np.linalg.lstsq(Jf(x), -f(x), rcond = None)[0]
        x = np.add(x_ant,h)
        e = np.linalg.norm(h, ord = 2)
        datos = np.array([k, h[0], h[1], h[2], x[0], x[1], x[2],  e])
        print("{} | {:13.8f}  | {:13.8f} | {:13.8f} | {:13.8f}  | {:13.8f} | {:13.8f} | {:16.10f}  ".format(*datos))
        k+=1

    print("\n=> Solucion: x =", x)

#--------------------------------------
x = np.array([0,0,1], dtype = 'f4')
n = len(x)
print(f(x))
print(Jf(x))
metNewtonENL(x)