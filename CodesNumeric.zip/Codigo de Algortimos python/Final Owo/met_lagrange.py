import sympy as sp
import numpy as np

puntos = [(-2, 32), (-1, 5), (0, 1), (1,1), (2,11), (3,61)]
n = len(puntos)
x = sp.symbols('x')

px = [par[0] for par in puntos]
py = [par[1] for par in puntos]


pol_lagrange = []

for i in range (n):
    pol = 1
    den = 1
    for j in range (n):
        if (i is not j):
            pol *= (x-px[j])
            den *= (px[i] - px[j])
    pol_lagrange.append(pol/den)

pol_int = 0
for i in range (n):
    print(pol_lagrange[i] * py[i], " + ")
    pol_int += pol_lagrange[i] * py[i]
