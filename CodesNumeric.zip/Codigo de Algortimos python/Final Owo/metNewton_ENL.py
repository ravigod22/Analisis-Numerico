import numpy as np
import sympy as sp
TOL = 1e-10

x = sp.symbols('x')
f = x**3
df = sp.diff(f, x)

e = 1
x_act = 0.5

i = 0
while(abs(e) > TOL):
    print(f'x = {x_act:5.10f} \tf(x) = {f.subs(x,x_act):5.10f} \t f\'(x) = {df.subs(x,x_act):5.10f}')
    x_ant = x_act
    x_act = x_ant - f.subs(x,x_ant) / df.subs(x,x_ant)
    e = abs(x_act - x_ant)
    i+=1

print(f'x = {x_act:5.10f} \tf(x) = {f.subs(x,x_act):5.10f} \t f\'(x) = {df.subs(x,x_act):5.10f}')
print("\nSolucion x =", x_act)