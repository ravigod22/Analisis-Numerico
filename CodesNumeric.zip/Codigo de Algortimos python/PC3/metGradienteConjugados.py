import numpy as np
from numpy import linalg as la

def metGradienteConjugado(A,b):
    n = len(A)
    DIM_MAX = 100
    rho = np.zeros(DIM_MAX)

    x_0 = np.array([-5.05,80.05,0])   
    x =  x_0
    r = b - A @ x
    rho[0] = la.norm(r, ord=2) ** 2
    k = 1
    epsilon = 1e-5
    print("====> METODO GRADIENTE CONJUGADO <====")
    print("Parametros:\t epsilon : ", epsilon, "\tx_0 = ", x_0, "\t r = p = ", b)
    print("--------------------------------------------------------------------------------------------------")

    while np.sqrt(rho[k-1]) > epsilon * la.norm(b, ord = 2) :
        if (k==1):
            p = r
        else:
            beta = rho[k-1] / rho[k-2]
            p = r + beta * p

        w = A @ p
        alpha = rho[k-1] / (p @ w)
        x = x + alpha * p
        r = r - alpha * w
        rho[k] = la.norm(r, ord=2) ** 2

        print("k =",k,"\t\tx = ", x, "\t\t Error = ", np.sqrt(rho[k-1])/la.norm(b, ord = 2))
        k += 1

#------------------------------
A=np.array([[0,0,1],
            [64,8,1],
            [256,16,1]],dtype='f4')
b=np.array([24,30,-24],dtype='f4')

A = A.transpose() @ A
b = A.transpose() @ b
metGradienteConjugado(A,b)