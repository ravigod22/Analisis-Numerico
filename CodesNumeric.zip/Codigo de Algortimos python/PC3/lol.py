import numpy as np

ROUNDING = 15
DIM = 3
tol = 1E-5
iter_max = 100
error = 2 * tol
it = 0

A = np.array([[69632,4608,320],
             [4608,320,24],
             [320,24,3]])
b = np.array([20480,2560,320])
x = np.array([0, 80.05, -5.05], dtype=float)
x_k = x
r = b - np.dot(A, x)
p = r
alpha = np.zeros(DIM)

while error > tol and it < iter_max:
    # Método

    # Transpuestas
    rt = np.transpose(r)
    pt = np.transpose(p)

    # alpha = rT . p / pT . A . p
    alpha = np.dot(rt, r) / np.dot(pt, np.dot(A, p))

    # x = x + alpha . p
    x = x + alpha * p

    # r = r + alpha . A . p
    rk = r - alpha * np.dot(A, p)

    # beta = rT . r / rT . r
    beta = np.dot(np.transpose(rk), rk) / np.dot(rt,r)

    # p = r + beta . p
    p = rk + beta * p
    r = rk
    # Impresión de resultados
    it = it + 1
    ER = np.dot(A, x) - b
    error = np.linalg.norm(ER, 2)
    print("Iteracion ", it)
    print("\tx = ", x)
    print("\tError residual = ", ER)
if it >= iter_max:
    if error > tol:
        print("NO CONVERGE")