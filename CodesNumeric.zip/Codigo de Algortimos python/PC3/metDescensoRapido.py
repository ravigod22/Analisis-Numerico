import numpy as np
from numpy import linalg as la

def metDescensoRapido(A,b):
    x_0 = np.zeros_like(b)
    x = x_0
    r = b - A @ x
    epsilon = 1e-5
    k = 1
    
    print("====> METODO DESCENSO RAPIDO <====")
    print("Parametros:\t epsilon : ", epsilon, "\tx_0 = ", x, "\tr = ", b)
    print("--------------------------------------------------------------------------------------------------")

    while la.norm(r,2) > epsilon * la.norm(b,2):
        alpha = (r @ r)/np.dot(r,A@r)
        x = x + alpha*r
        r = b - A@x
        print("k =",k,"\t\tx = ", x, "\t\t Error = ", la.norm(r,2)/la.norm(b,2))
        k += 1
        
#------------------------------
A=np.array([[0,0,1],
            [64,8,1],
            [256,16,1]],dtype='f4')
b=np.array([24,30,-24],dtype='f4')

A = A.transpose() @ A
b = A.transpose() @ b

metDescensoRapido(A,b)