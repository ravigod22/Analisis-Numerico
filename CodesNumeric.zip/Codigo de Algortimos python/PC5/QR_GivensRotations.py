import numpy as np

def QR_Givens(A):
    m, n = A.shape
    R = A.copy()
    Q = np.eye(m)

    print("\n =>  Factorización QR - Transformaciones Givens")
    for j in range(n):
        for i in range(j + 1, m):
            if R[i, j] != 0:
                r = np.sqrt(R[j, j] ** 2 + R[i, j] ** 2)
                c = R[j, j] / r
                s = -R[i, j] / r

                G = np.eye(m)
                G[[j, i], [j, i]] = c
                G[i, j] = s
                G[j, i] = -s

                R = G @ R
                Q = Q @ G.T
                print("---------------------------------------------------------------")
                print(f"G_{i + 1}{j + 1}:\n", G)
                print(f"R_{i + 1}{j + 1}:\n", R)
                print(f"Q_{i + 1}{j + 1}:\n", Q)
    print("---------------------------------------------------------------")
    return Q, R




# ----------------------------------------------
print("=> DATOS DEL PROBLEMA")
A = np.array([[1, 1, 1],
              [12, 10, 9],
              [2, -1, 0]],dtype='f4')

b = np.array([44, 436, 0],dtype='f4')

r = np.linalg.matrix_rank(A)

print("Matriz A: => ran(A) =", r )
print(A)
print("Vector de coeficientes b: ")
print(b)


Q,R = QR_Givens(A)

print("Matrices Resultantes de la Factorizacion QR")
print("Q =")
print(Q)
print("\nR =")
print(R)

print("QxR")
print(Q @ R)
c = Q.T @ b
print("\nSistema Resultante: R x = Q^t b")
print("Q^t b = c = ", c)
print("Resolviendo el sistema se tiene  x = ", np.linalg.solve(R,c))
