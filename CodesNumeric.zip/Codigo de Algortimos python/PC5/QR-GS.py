import numpy as np

def QR_Gram_Schmidt_clasico(A):
    m, n = A.shape
    Q = np.zeros((m, n))
    R = np.zeros((n, n))

    #print("QR-Gram-Schmidt (clasico)")
    for j in range(n):
        v = A[:, j]
        for i in range(j):
            R[i, j] = np.dot(Q[:, i], A[:, j])
            v -= R[i, j] * Q[:, i]
        R[j, j] = np.linalg.norm(v)
        Q[:, j] = v / R[j, j]

    return Q, R


def QR_Gram_Schmidt_modificado(A):
    m, n = A.shape
    Q = np.zeros((m, n))
    R = np.zeros((n, n))

    #print("QR-Gram-Schmidt (modificado)")
    for j in range(n):
        v = A[:, j]
        for i in range(j):
            R[i, j] = np.dot(Q[:, i], v) / np.dot(Q[:, i], Q[:, i])
            v -= R[i, j] * Q[:, i]
        R[j, j] = np.linalg.norm(v)
        Q[:, j] = v / R[j, j]

    return Q, R



# ----------------------------------------------
# Circuito - Leyes de Kirchoff
print("=> DATOS DEL PROBLEMA")
A = np.array([[300, 0, 150],
              [0, 102, -150],
              [1, -1, -1]],dtype='f4')

b = np.array([7.5, 11.5, 0],dtype='f4')

r = np.linalg.matrix_rank(A)

print("Matriz A: => ran(A) =", r )
print(A)
print("Vector de coeficientes b: ")
print(b)


# METODO
#Q,R = np.linalg.qr(A)
Q,R = QR_Gram_Schmidt_clasico(A)


print("\n------- Factorización QR-Gram-Schmidt (clasico)-------")
print("Q:")
print(Q)
print("R: ")
print(R)
c = np.transpose(Q) @ b
print("\nSistema Resultante: R x = Q^t b")
print("Q^t b = c = ", c)
print("Resolviendo el sistema se tiene  x = ", np.linalg.solve(R,c))
