import numpy as np

ITER_MAX = 100
TOL = 1e-12

def metBiseccion(f, a, b):
    c = (a + b) / 2
    if a < b and f(a) * f(b) < 0:
        print("-----------------METODO DE BISECCION-----------------")
        print("f(x) = myFuncion \t\t\t a = {} , b = {}".format(a, b))
        print("\n i  |       a        |        b       |       c        |    f(a)     |    f(b)     |    f(c)     |  Error")
        print("----+----------------+----------------+----------------+-------------+-------------+-------------+---------------")
        i = 0
        while i < ITER_MAX and b - a > TOL:
            c = (a + b) / 2
            datos = np.array([i, a, b, c, f(a), f(b), f(c), 1 if i==0 else min(abs(a-c),abs(b-c))], dtype='f4')
            print("{} | {:14.10f} | {:14.10f} | {:14.10f} | {:11.8f} | {:11.8f} | {:11.8f} | {:11.8f}".format(*datos))
            if f(c) * f(a) > 0:
                a = c
            elif f(c) * f(b) > 0:
                b = c
            elif f(c) == 0:
                a = c
                b = c
            
            i += 1
        print("\nSolucion x =", c)
        print("Numero de iteraciones:", i)
    else:
        print("METODO NO CONVERGE - No hay solución en dicho intervalo")


def metReglaFalsa(f, a, b):
    c = b - f(b)*(b-a)/(f(b)-f(a))
    if a < b and f(a) * f(b) < 0:
        print("-----------------METODO DE REGLA FALSA-----------------")
        print("f(x) = myFuncion \t\t\t a = {} , b = {}".format(a,b))
        print("\n i  |       a       |       b       |    Error|f(c_i)|")
        print("----+---------------+---------------+--------------------")
        datos = np.array([0, a, b], dtype='f4')
        print("{} | {:13.10f} | {:13.10f} |       ------".format(*datos))
        i = 1
        while abs(f(c)) >= TOL and i<ITER_MAX:
            if f(c) * f(a) > 0:
                a = c
            else:
                b = c
            
            datos = np.array([i, a, b, f(c)], dtype='f4')
            print("{} | {:13.10f} | {:13.10f} | {:9.15f}".format(*datos))
            c = b - f(b)*(b-a)/(f(b)-f(a))

            i += 1
        print("\nSolucion x =",c)
        print("Numero de iteraciones :",i)
    else:
        print("METODO NO CONVERGE - No hay solución en dicho intervalo")
     
def metReglaFalsa_modificada(f, a, b, alpha):
    if a < b and f(a) * f(b) < 0:
        i = 0
        c = b - f(b)*(b-a)/(f(b)-f(a))

        print("-----------------METODO DE REGLA FALSA (modificada)-----------------")
        print("f(x) = myFuncion \t a = {} \t b = {} \t alpha = {}".format(a,b,alpha))
        print("\n i  |       a        |       b       |       c       |   Error|b_k-a_k|   |   Error|f(c_i)|")
        print("----+----------------+---------------+---------------+--------------------+-------------------")
        datos = np.array([i, a, b, c, abs(b-a), abs(f(c))], dtype='f4')
        print("{} | {:13.10f}  | {:13.10f} | {:13.10f} | {:13.15f}  | {:13.15f} ".format(*datos))

        while abs(f(c)) > TOL and i < ITER_MAX:
            if f(c) * f(b) < 0:
                a = b
                fa = f(a)
            else:
                fa = alpha * f(a)
            i += 1
            b = c
          
            c = b - f(b)*(b-a)/(f(b)-fa)
            
            datos = np.array([i, a, b, c, abs(b-a), abs(f(c))], dtype='f4')
            print("{} | {:13.10f}  | {:13.10f} | {:13.10f} | {:13.15f}  | {:13.15f} ".format(*datos))

        print("\nSolucion x =",c)
        print("Numero de iteraciones :",i)
    else:
        print("METODO NO CONVERGE - No hay solución en dicho intervalo")

# -------------------------------------------------------------------------------------------
# Definimos la funcion f y nuestros parametros del intervalo
a = 1
b = 3
alpha = 0.5
#f = lambda x: x * np.sin(x) - 1
f = lambda x: 0.5 * np.log(x**2 + 1) + x - x**2 / 2
#f = lambda x: x**2 - 7

metReglaFalsa(f, a, b)
