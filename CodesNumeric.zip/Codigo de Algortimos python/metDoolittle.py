import numpy as np
def mostrarMatriz(A):
    n,m = A.shape
    for i in range(0,n):
        strMatr = "[\t"
        for j in range(0,m):
            strMatr +=  str(A[i][j])+"\t"
        strMatr += "]"
        print(strMatr)

def metodoDoolittle(A, n):
    L = np.zeros((n,n))
    U = np.zeros((n,n))
    for i in range (n):
        for i in range (n):
            L[i][i] = 1
    for i in range (n):
        for j in range (i):
            sum = 0
            for k in range (j):
                sum += L[i][k] * U[k][j]
            L[i][j] = (A[i][j] - sum) / U[j][j]
        for j in range (i, n):
            sum = 0
            for k in range (i):
                sum += L[i][k] * U[k][j]
            U[i][j] = (A[i][j] - sum) / L[i][i]
    return L, U
# ---------------------------------------------

A = np.array([[625, 125, 25, 5, 1],
              [256, 64, 16, 4, 1],
              [81, 27, 9, 3, 1],
              [16, 8, 4, 2, 1],
              [1, 1, 1, 1, 1]])
L,U = metodoDoolittle(A, len(A))

print("Matriz A:")
mostrarMatriz(A)
print("Matriz L:")
mostrarMatriz(L)
print("Matriz U")
mostrarMatriz(U)