import numpy as np

# Definir la matriz A y el vector b
A=np.array([[6,-3,0],
            [0,-1,1],
            [2,-6,5]],dtype='f4')
b=np.array([-1,0,1],dtype='f4')

# Calcular la factorización QR de A
Q, R = np.linalg.qr(A)

# Extraer las dimensiones de R
n, m = R.shape

# Resolver el sistema R*x = Q^T * b
x = np.linalg.solve(R[:m, :], np.dot(Q[:, :m].T, b))

# Calcular los residuos
residuals = np.linalg.norm(np.dot(A, x) - b)

# Calcular el rango de la matriz A
rank = np.linalg.matrix_rank(A)

# Imprimir los resultados
print("Solución x:")
print(x)
print("Residuos:")
print(residuals)
print("Rango:")
print(rank)
