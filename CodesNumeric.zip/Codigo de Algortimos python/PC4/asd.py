import numpy as np

# Definir la matriz A y el vector b
A = np.array([[6,-3,0],
            [0,-1,1],
            [2,-6,5]],dtype='f4')
b = np.array([-1,0,1],dtype='f4')

# Calcular la matriz pseudo-inversa de A
A_pInv = np.linalg.pinv(A)

# Calcular la solución por mínimos cuadrados
x = A_pInv @ b

# Calcular los residuos
r = np.linalg.norm(A @ x - b)

# Imprimir los resultados
print("Solución x:", x)
print("Residuos:", r)
