from numpy import linalg as la
import numpy as np

def descomposicionQR(A,b):
    Q, R = la.qr(A)  # Descomposición QR
    print (f"Q:\n", Q)
    print (f"R:\n", R)
    print(la.matrix_rank(Q))
    print(la.matrix_rank(R))

    y = np.transpose(Q) @ b
    x = la.solve(R,y)
    return x

# ---------------------------------------
A=np.array([[6,-3,0],
            [0,-1,1],
            [2,-6,5]],dtype='f4')
b=np.array([-1,0,1],dtype='f4')

x, residuals, rank, s = la.lstsq(A, b, rcond=None)

print(x)

