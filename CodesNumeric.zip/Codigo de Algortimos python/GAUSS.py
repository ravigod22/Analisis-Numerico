import numpy as np

def mostrarMatriz(matriz,n):
    for i in range(0,n):
        strMatr = "[\t"
        for j in range(0,n+1):
            strMatr +=  str(matriz[i][j])+"\t"
        strMatr += "]"
        print(strMatr)

def calcularF_ij_l(matriz, i, j, l, n):
    print("\nSe resta " ,l, " veces la fila ", i , " a la fila ", j )
    for k in range (0,n+1):
        matriz[i][k] -= l*matriz[j][k]
    mostrarMatriz(matriz,n)

def calcularF_ij(matriz, i, j, n):
    print("\nSe intercambian las filas ", i , " y ", j)
    for k in range (0,n+1):
        aux = matriz[j][k]
        matriz[j][k] = matriz[i][k]
        matriz[i][k] = aux
    mostrarMatriz(matriz,n)

def metodoGauss(matriz,n):
    for i in range (0,n-1):
        p = i
        while(matriz[p][i]==0):
            p+=1
            if (i>n):
                print("No existe solucion")
                return []
        if p != i:
            calcularF_ij(matriz, i, p, n)
        for j in range (i+1,n):
            fji = matriz[j][i]/matriz[i][i]
            if (fji!=0): print("\nes cero\n")
            calcularF_ij_l(matriz, j, i, fji, n)
    if matriz[n-1][n-1] == 0:
        print("No existe solucion")
        return []

    # Inicializamos el array con ceros
    x = np.zeros(n)
    # Sustitucion regresiva
    print("\nAplicando sustitución regresiva se tiene las siguientes soluciones: ")
    x[n-1] = matriz[n-1][n] / matriz[n-1][n-1]
    for i in range(n-2,-1,-1):
        suma = 0
        for j in range(i+1,n):
            suma += matriz[i][j]*x[j]
        x[i] = (matriz[i][n]-suma) / matriz[i][i]
    
    return (x)

A = [[1,0,0,-3,-5,0,0,5], 
     [0,1,0,-8,-4,0,0,0], 
     [0,0,1,-2,-6,0,0,10],
     [0,0,0,1,0,-7,-8,5],
     [0,0,0,0,1,-6,-2,2],
     [0,0,0,0,0,1,0,3],
     [0,0,0,0,0,0,1,4]]

print("------MATRIZ INICIAL---------")
mostrarMatriz(A,len(A))
print("------Aplicando el metodo de GAUSS---------")
x = metodoGauss(A,len(A))

# Mostrar los valores de las variables
for i in range(0,len(x)):
	print(" - x"+str(i+1)+" = "+str(x[i]))



	

        
    
    
