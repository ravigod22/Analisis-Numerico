f1 = lambda x,y : x*x + x*y - 77
f2 = lambda x,y : y*y + x*y -44

dy = lambda x,y : ((2*x+y)*42 - 75*y)/(4*x*y+2*x*x+2*y*y)
dx = lambda x,y : (42 - (2*y+x)*((2*x+y)*42 - 75*y)/(4*x*y+2*x*x+2*y*y))/y

h1 = lambda x,y : (x*(y*y+x*y-44) - (2*y+x)*(x*x +x*y-77))/(2*(x+y)**2)
h2 = lambda x,y : (y*(x*x +x*y-77) -(2*x+y)*(y*y+x*y-44))/(2*(x+y)**2)

x0=y0=1
dl = 0.1
x=[x0] ; y=[y0]
for i in range(1,11):
    # aproximacion por diferenciales
    xx = x[i-1] + dl * dx(x[i-1],y[i-1])
    yy = y[i-1] + dl * dy(x[i-1],y[i-1])
    x += [xx]
    y += [yy]
print("X es:\n")
print(x)
print("\nY es:\n")
print(y)
print(f1(x[-1],y[-1]))
print(f2(x[-1],y[-1]))
xx = x[-1]
yy = y[-1]
for i in range(5):  
    xx = xx + h1(xx,yy)
    yy = yy + h2(xx,yy)
print(f1(xx,yy))
print(f2(xx,yy))
print("La solucion es: ")
print("X = " + str(xx))
print("Y = " + str(yy))
