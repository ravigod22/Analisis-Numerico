import math
import numpy as np

def F(x):
    f1=x[0]*x[1]-42
    f2=x[0]*x[1]+5*x[0]+5*x[1]-107
    return np.array([f1,f2])

def dF(x):
    return np.array([[x[1],x[0]],
                     [x[1]+5,x[0]+5]])

N=100
x=np.array([3,4])

for k in range(N):
    xold=x
    Jinv=np.linalg.inv(dF(x))
    x=x-np.dot(Jinv,F(x))
    e=np.linalg.norm(x-xold)
    #print("Matriz Jacobiana")
    #print(Jinv)
    print("iter\t x0\t x1\t error")
    print(k,"\t",x[0],"\t,",x[1],"\t",e)
    print()
    if e<1e-5:
        print("Solucion: ")
        print("x0=",x[0],"y x1=",x[1])
        break
