from numpy import sin
import numpy as np
import sys
def reglafal(f,a,b):
    eps=1E-5
    maxIter=10000
    fa=f(a)
    fb=f(b)
    i=0
    while i<maxIter and b-a>=eps:
        c = a - fa * (b-a)/(fb-fa)
        fc=f(c)
        i+=1
        if fc==0:
            a=b=c
        elif fa*fc<0:
            b=c; fb=fc
        else:
            a=c; fa=fc
        print(f'iteración {i}: [a,b]=[{a},{b}]')
    if b-a>=eps:
        print(f'Método no converge')
    else:
        print(f'Solución c = {c}')
        print(f'Número de iteraciones = {i}')

reglafal(f = lambda x:(sys.float_info.epsilon**(-x/2))*(1 + x/2 + (1/2)*((x/2)**2) + (1/6)*((x/2)**3)) - 0.1,a=0,b=10)

def h(x):
    return (sys.float_info.epsilon**(-x/2))*(1 + x/2 + (1/2)*((x/2)**2) + (1/6)*((x/2)**3)) - 0.1

x=np.linspace(1,2,100)
