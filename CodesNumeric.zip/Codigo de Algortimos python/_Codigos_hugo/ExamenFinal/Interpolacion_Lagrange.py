import sympy as sym
# Interpolacion de Lagrange
# divisoresL solo para mostrar valores
import numpy as np
import matplotlib.pyplot as plt

###Datos###
xi = np.array([0, 0.5, 1, 2])
#xi = np.array([-1, 0, 1])

fi = np.array([1, 2, 1.5, -1])
#fi = np.array([0.5, 1, -1])

# PROCEDIMIENTO
# Polinomio de Lagrange
n = len(xi)
x = sym.Symbol('x')
polinomio = 0
divisorL = np.zeros(n, dtype = float)
for i in range(0,n,1):
    # Termino de Lagrange
    numerador = 1
    denominador = 1
    for j  in range(0,n,1):
        if (j!=i):
            numerador = numerador*(x-xi[j])
            denominador = denominador*(xi[i]-xi[j])
    terminoLi = numerador/denominador
    divisorL[i] = denominador
    print("L",i+1,": ",terminoLi)
    polinomio = polinomio + terminoLi*fi[i]
    print("T",i+1,": ",terminoLi*fi[i])
    print()  

polisimple = polinomio.expand()
px = sym.lambdify(x,polisimple)

# Salida
print("==========================================================")
print('    valores de xi: ',xi)
print('    valores de fi: ',fi)
print('divisores en L(i): ',divisorL)
print()
#E(x)=f(x)-Pn(x)
print("Errores:")
for i in range(len(xi)):
    k=xi[i]
    error=fi[i]-polisimple.subs(x,k)
    print("x",i,": ",error)
print()
print('Polinomio completo')
print(polinomio)
print()
print('Polinomio de Lagrange (simplificado): ')
print(polisimple)
print()
###Comprobando###
print("Comprobaciones:")
for i in range(len(xi)):
    print("Para x=",xi[i]," f(x)=",polisimple.subs(x,xi[i]))
print()


###Gráficas###
#Graf 1
muestras = 201
a = -8
b = 10
pxi = np.linspace(a,b,muestras)
pfi = px(pxi)
plt.plot(xi,fi,'o', label = 'Puntos')
plt.plot(pxi,pfi, label = 'Polinomio')
plt.legend()
plt.xlabel('xi')
plt.ylabel('f(xi)')
plt.title('Interpolación Lagrange Graf1')
plt.show()

#Graf 2
muestras = 101
a = np.min(xi)
b = np.max(xi)
pxi = np.linspace(a,b,muestras)
pfi = px(pxi)
plt.plot(xi,fi,'o', label = 'Puntos')
plt.plot(pxi,pfi, label = 'Polinomio')
plt.legend()
plt.xlabel('xi')
plt.ylabel('f(xi)')
plt.title('Interpolación Lagrange Graf2')
plt.show()
