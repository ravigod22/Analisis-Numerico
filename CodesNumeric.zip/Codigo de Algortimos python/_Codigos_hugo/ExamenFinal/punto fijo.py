from numpy import sin
import numpy as np
def puntofijo(f,x0):
    eps = 1E-5
    maxIter=100
    f0=f(0)
    i=0
    while i<maxIter and abs(f0-x0)>=eps:
        x0=f0
        f0=f(x0)
        i+=1
        print(f'iteración {i}: x0 = {x0} f(x0) = {f0}')
    if abs(f0-x0)>=eps:
        print(f'Método no converge')
    else:
        print(f'Solución c = {x0}')
        print(f'Número de iteraciones = {i}')

puntofijo(f = lambda x: 4 + sin(2*x)/3,x0=0)

def h(x):
    return (4 + sin(2*x)/3)

x=np.linspace(-10,10,100)
