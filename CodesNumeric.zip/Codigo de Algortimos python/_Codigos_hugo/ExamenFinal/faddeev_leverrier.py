import math as mth 
import numpy as np 

A = np.array([[48.8,0],[0,51.2]]) 
n = 2
C = np.zeros(n+1) 
M = list([]) 

for k in range(0,n+1): 
  if k == 0:
    M.append(np.zeros((n,n))) 
    C[n-k] = 1
  else:
    M.append(np.dot(A,M[k-1])+np.dot(C[n-k+1],np.identity(n))) 
    C[n-k] = -1/k*np.trace(np.dot(A,M[k])) 

C = np.fliplr([C])[0] 

pol= str("p(x) = ")
for i in range(n+1):
  pol = pol + "("+ str(C[i]) + ")"+ " * x^"+str(n-i)+" + "

print("Polinomio caracteristico:","\n",pol[:-8])
print("\n")
print("Autovalores:","\n",np.roots(C)) 
