import numpy as np
def normInfinito(A):
    
    h = []
    
    for i in range(A.shape[0]):
        suma = 0
        for j in range(A.shape[1]):
            suma = suma + abs(A[i,j])
        
        h.append(suma)
        
    return max(h)
def getMaxAbs(x,puesto):
    
    myArray = []
    for i in x:
        myArray.append(abs(i))
    
    maxNum = 0
    
    if puesto == 1:
        maxNum = max(myArray)
        return maxNum
    if puesto == 2:
        myArray.remove(max(myArray))
        maxNum = max(myArray)
        return maxNum
    
    return maxNum


#========Metodo de potencia Escalado==================
def metPotenciaEscalado(x,A):
    
    n = len(A)
    maxInter = 1000
    TOL = 1E-10
    u = 0 #Eigevalor
    k = 1
    
    p = 0
    
    for d in range(len(x)):
        if abs(x[d,0]) == normInfinito(x):
            p = d
            break
        
    
    x = x/x[p,0]
    
    while k <= maxInter:
        y = np.dot(A,x)

        u = y[p,0]
        
        for l in range(len(x)):
            if abs(y[l,0]) == normInfinito(y):
                p = l
                break
            
        if y[p,0] == 0:
            print("Eigevector dominante:")
            print(x)
            print("A tinen el eigevalor, selecione otro x  y reinicie")
            return
        
        ERR = normInfinito(x-(y/y[p,0]))
        
        x = y/y[p,0]

        
        if ERR < TOL :
            print("Eigevalor dominante: "+str(round(u,4)))
            print("Eigevector dominante:")
            print(np.transpose(x))
            lamda1 = getMaxAbs(x,1)
            print("Lamda1 = "+str(lamda1))
            lamda2 = getMaxAbs(x,2)
            print("Lamda2 = "+str(lamda2))
            print("|lamda2/lamda1| = Tasa: "+str(lamda2/lamda1))
            print("El procedimiento fue exitoso")
            
            return
        
        salida = "xt{0:2.0f} = [x1={1:.10f} x2 = {2:.10f} x3 = {3:.10f} x4 = {4:.10f}]   ut = {5:.10f}  Err = {6:.10f}"
        print(salida.format(k,x[0,0],x[1,0],x[2,0],x[3,0],u,ERR))
        k = k + 1
    
    print("El numero maximo de iteraciones exedio")
    print("El procedimiento no fue exitoso")
    return



x0 = np.array([[1],[1],[1],[1]],float)

A = np.array([ [-30,2,3,13],
                [5,11,10,8],
                [9,7,6,12],
                [4,14,15,1]],float)




metPotenciaEscalado(x0,A)


