import numpy as np
import sympy as sym

def neville (x, y, x0) :   
    n = len(x)
    Q = np.zeros(shape =(n, n), dtype = float)
    for i in np . arange ( n ) :
        Q [i][0] = y[i]
    for i in np . arange (1, n) :
        for j in np . arange (1 , i + 1) :
            f = (x0 - x [i - j ]) * Q [i][j - 1] - (x0 - x [ i ]) * Q [i - 1][j - 1]
            g = x[i] - x[i -j]
            Q[i][j] = f/g
    print("Valores de x: ",x)
    print("Tabla de aproximaciones")
    print(Q)

if __name__ == '__main__':
    x = np.array([1.0 , 1.3 , 1.6 , 1.9 , 2.2] , dtype = float )
    y = np.array([0.7651977 , 0.6200860 , 0.4554022 , 0.2818186 , 0.1103623])
    neville (x, y, 1.5)

