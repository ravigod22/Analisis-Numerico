from numpy import sin
import sys
eps = 1E-5
maxIter=100
f = lambda x : (sys.float_info.epsilon**(-x/2))*(1 + x/2 + (1/2)*((x/2)**2) + (1/6)*((x/2)**3)) - 0.1
a = 0
b = 10
fa = f(a)
fb = f(b)
i = 0
while i<maxIter and b-a>=eps:
    c=(a+b)/2
    fc=f(c)
    i+=1
    if fc==0:
        a=b=c
    elif fa*fc<0:
        b=c; fb=fc
    else:
        a=c; fa=fc
    print(f'[a,b]=[{a:5.2f}, {b:5.2f}]')
if b-a>=eps:
    print(f'Metodo no converge')
else:
    print(f'Solucion c={c}')
    print(f'Numero de iteraciones={i}')
#PierreAdanCamiloRuizRosas
