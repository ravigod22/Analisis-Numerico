def mostrarMatriz(matriz, orden):
    for i in range(0, orden):
        linea = "| "
        for j in range(orden + 1):
            linea += str(matriz[i][j]) + " "
        linea += "| "
        print(linea)

matriz = [[120,200,80,100,2020], [-1,1,0,-1,0], [0,1,-3,0,0], [1,1,1,1,14]]
orden = len(matriz)
mostrarMatriz(matriz, orden)

for j in range(0, orden + 1):
    for i in range(0, orden):
        if i > j:
            if matriz[j][j] == 0:
                print("La matriz es singular o mal condicionada. No se puede continuar.")
                exit(1)  
            division = matriz[i][j] / matriz[j][j]
            for k in range(0, orden + 1):
                matriz[i][k] = matriz[i][k] - division * matriz[j][k]

x = [0] * orden  
for i in range(orden, 0, -1):
    suma = 0
    for j in range(i, orden):
        suma += matriz[i - 1][j] * x[j]
    if matriz[i - 1][i - 1] == 0:
        print("La matriz es singular o mal condicionada. No se puede continuar.")
        exit(1) 
    x[i - 1] = (matriz[i - 1][orden] - suma) / matriz[i - 1][i - 1]

for i in range(orden):
    print("x" + str(i) + " = " + str(x[i]))
