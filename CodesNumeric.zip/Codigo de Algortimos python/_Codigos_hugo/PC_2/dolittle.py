import numpy as np
n = int(input("Ingrese el orden de la matriz: "))
A = np.zeros((n, n))
for i in range (0,n):
    for j in range (0,n):
        A[i][j] = int(input("Ingrese el elemento: "))
print(A)
L = np.identity(n)
for i in range(0, n)
    for j in range(1, i-1):

    for j in range(i, n):
        

