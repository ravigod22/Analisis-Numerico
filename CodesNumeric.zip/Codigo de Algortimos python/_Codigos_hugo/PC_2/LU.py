import numpy as np
n = int(3)
A = np.array([[4,2,5],
              [2,5,8],
              [5,4,3]])
l = np.zeros([3,3])
u = A
for i in range(0,n):
    for j in range(0,n):
        if(i==j):
            l[i,j]=1
        if(i<j):
            aux=(A[j,i]/A[i,i])
            l[j,i]=aux
            for p in range(0,n):
                A[j,p]-=aux*A[i,p]
                u[j,p]=A[j,p]
print(u)
print(l)
