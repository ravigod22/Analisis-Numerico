#import matplotlib.pyplot as plt
import math
import numpy as np


def myFunctionAevaluar(a):
    
    # Definnir la funcion, debe se continua
    #f = math.pow(a,3)-3*a+1
    f = a - pow(7,1/2)
    #f = math.pow(a,3)+4*math.pow(a,2)-10
    #f = math.pow(a,3)-2*math.sin(a)
    
    return f

#Graficando

X = np.arange(-0.5,5,0.01)
Y = []

for i in X:
    Y.append(myFunctionAevaluar(i))

"""plt.plot(X,Y)
plt.grid()
plt.show()"""

#Ingresando datos
print("Ingrese a y b / f(a).f(b) < 0")

a = float(input("Ingrese a: "))
b = float(input("Ingrese b: "))

#TOL = float(input("Ingrese la tolerancia:"))

numMaxInter = int(input("Ingrese el numero de interacciones:"))

#---------

FA = myFunctionAevaluar(a)
print("-------------------------------------------------------------------------------------------------------------------")
print("n".ljust(2)+"    an".ljust(30)+"bn".ljust(30)+"cn".ljust(30)+"f(cn)".ljust(30))
print("-------------------------------------------------------------------------------------------------------------------")


FA = myFunctionAevaluar(a)
FB = myFunctionAevaluar(b)

sol = 0.0

if FA*FB >= 0:
    print ("a="+str(a)+" b="+str(b)+" F(a)="+str(FA)+" F(b)="+str(FB))
    print("La funcion tienen igual signo en a y b")

else:

    for i in range(numMaxInter):
        erro = (b-a)/2
        c = a + erro   #c=(a+b)/2
        FC = myFunctionAevaluar(c)

        if abs(erro) < 1E-5:  #TOL
            print("La solucion Converge para Epsilon dado")
            print("La solucion aproximada es: " + str(sol))
            print("El vuelto se da por 5 menos raiz de 7, el cual es: " + str(5-sol))
            break
        print(str(i+1).ljust(2)+"  "+str(a).ljust(30)+" "+str(b).ljust(30)+" "+str(c).ljust(30)+" "+str(FC).ljust(30))
        sol = c
        if FA*FC < 0:
            b = c
            FB = FC
        else:
            a = c
            FA = FC










