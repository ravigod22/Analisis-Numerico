def sobrecarga_n(n, a, b):
    c = a+b
    for i in range(1,n+1):
        if((c/pow(10, i-1))%10>1):
            if(i==n):             
                c-=c/pow(10,i-1)%10 * pow(10,i-1)
            else:
                c-=c/pow(10,i-1)%10 * pow(10,i-1)
                c+=pow(10, i)
    return c
k=1
cont=0
n=int(input("Ingresa el numero de digitos: "))
c = sobrecarga_n(n, 1, 1111)
if(c==0):
    print('0000')
else: 
    cad=''
    cant = len(str(c))
    cant = n-(cant-2)
    for i in range (0,cant):
        cad+='0'
    print(cad + str(round(c)))
