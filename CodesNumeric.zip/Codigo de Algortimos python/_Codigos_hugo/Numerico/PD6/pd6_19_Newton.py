# Interpolacion de Newton
import numpy as np
import sympy as sym
import matplotlib.pyplot as plt

###Datos###
#Periodo
xi = np.array([1975, 1980, 1985, 1990])

##Esperanza de vida
#Europa del Oeste
fi = np.array([72.8, 74.2, 75.2, 76.4])

#Europa del Este
#fi = np.array([70.23, 70.2, 70.3, 71.2])

# PROCEDIMIENTO

# Tabla de Diferencias Divididas Avanzadas
titulo = ['i   ','xi  ','fi  ']
n = len(xi)
ki = np.arange(0,n,1)
tabla = np.concatenate(([ki],[xi],[fi]),axis=0)
tabla = np.transpose(tabla)

# diferencias divididas vacia
dfinita = np.zeros(shape=(n,n),dtype=float)
tabla = np.concatenate((tabla,dfinita), axis=1)

# Calcula tabla, inicia en columna 3
[n,m] = np.shape(tabla)
diagonal = n-1
j = 3
while (j < m):
    # Añade título para cada columna
    titulo.append('F['+str(j-2)+']')

    # cada fila de columna
    i = 0
    paso = j-2 # inicia en 1
    while (i < diagonal):
        denominador = (xi[i+paso]-xi[i])
        numerador = tabla[i+1,j-1]-tabla[i,j-1]
        tabla[i,j] = numerador/denominador
        i = i+1
    diagonal = diagonal - 1
    j = j+1

# POLINOMIO con diferencias Divididas
# caso: puntos equidistantes en eje x
dDividida = tabla[0,3:]
n = len(dfinita)

# expresión del polinomio con Sympy
x = sym.Symbol('x')
polinomio = fi[0]
for j in range(1,n,1):
    factor = dDividida[j-1]
    termino = 1
    for k in range(0,j,1):
        termino = termino*(x-xi[k])
    polinomio = polinomio + termino*factor

# simplifica multiplicando entre (x-xi)
polisimple = polinomio.expand()

# polinomio para evaluacion numérica
px = sym.lambdify(x,polisimple)

# Puntos para la gráfica
muestras = 101
a = np.min(xi)
b = np.max(xi)
pxi = np.linspace(a,b,muestras)
pfi = px(pxi)

# SALIDA
np.set_printoptions(precision = 4)
print('Tabla Diferencia Dividida')
print([titulo])
print(tabla)
print('dDividida: ')
print(dDividida)
print()
#E(x)=f(x)-Pn(x)
print("Errores:")
for i in range(len(xi)):
    k=xi[i]
    error=fi[i]-polisimple.subs(x,k)
    print("x",i,": ",error)
print()
print('Polinomio completo: ')
print(polinomio)
print()
print('Polinomio simplificado: ' )
print(polisimple)
print()

###Comprobando###
print("Comprobaciones:")
for i in range(len(xi)):
    print("Para x=",xi[i]," f(x)=",polisimple.subs(x,xi[i]))
print()

###Estimaciones###
estxi=[1977,1983,1989]
estfi=[]
print("Estimaciones:")
for i in range(len(estxi)):
    print("Para x=",estxi[i]," f(x)=",polisimple.subs(x,estxi[i]))
    estfi=np.append(estfi,polisimple.subs(x,estxi[i]))
print()


xi=np.append(xi,estxi)
fi=np.append(fi,estfi)

# Gráfica
plt.plot(xi,fi,'o', label = 'Puntos')
for i in range(0,n,1):
   plt.axvline(xi[i],ls='--', color='yellow')
plt.plot(pxi,pfi, label = 'Polinomio')
plt.legend()
plt.xlabel('xi')
plt.ylabel('fi')
plt.title('Diferencias Divididas - Newton')
plt.show()
