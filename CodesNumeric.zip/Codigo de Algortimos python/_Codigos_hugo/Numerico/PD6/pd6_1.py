from __future__ import division
import numpy as np
from numpy.linalg import solve
 
def broyden_good(x, y, f_equations, J_equations, tol=10e-10, maxIters=50):
    steps_taken = 0
 
    f = f_equations(x,y)
    J = J_equations(x,y)
 
    while np.linalg.norm(f,2) > tol and steps_taken < maxIters:
 
        s = solve(J,-1*f)
 
        x = x + s[0]
        y = y + s[1]
        newf = f_equations(x,y)
        z = newf - f
 
        J = J + (np.outer ((z - np.dot(J,s)),s)) / (np.dot(s,s))
 
        f = newf
        steps_taken += 1
        print("Iteración", steps_taken, "x=",x,"y=",y)
    return steps_taken, x, y  
 
tol = 10.0** -15
maxIters = 50
x0 = 1
y0 = 0
 
def fs(x,y):
    return np.array([x**2 + y**2 - 290, x + y - 24])
 
def Js(x,y):
    return np.array([[2,0],
             [1, 1]])
 
n, x, y = broyden_good(x0, y0, fs, Js, tol, maxIters=50 )
print("El método tomó: ", n, "iteraciones")
print("x= ", x, "y=", y)