import numpy as np
a = np.array([[30,2,3,13],[5,11,10,8],[9,7,6,12],[4,14,15,1]])
n=4
x=np.zeros((n))
print('Ingrese el vector x_0: ')
for i in range(n):
    x[i]=float(input('x[{}]='.format(i+1)))
tol=10**(-10)
lambda_a=1.0
condicion=True
ite=1
while condicion:
    lambda_n=max(abs(x))
    x=x/lambda_n
    print('\n Iteracion:{}'.format(ite))
    print('*******************************')
    print('Autovalor={0:.10f}'.format(lambda_n))
    print('Autovector: ')    
    for i in range (n):
        print('{0:.15f}\t'.format(x[i]))
    ite=ite+1
    error=abs(lambda_n-lambda_a)
    print('error={}'.format(error))
    print('***************************') 
    lambda_a=lambda_n
    condicion = error>tol   