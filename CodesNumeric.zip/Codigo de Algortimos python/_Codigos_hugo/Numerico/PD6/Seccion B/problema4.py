from numpy import dot, sqrt ,array
from numpy.linalg import solve
def broyden(x0,A0):
    TOL=1E-5
    MAXITER=100
    k=0
    xk=x0
    Ak=A0
    terminar=False
    while not terminar:
        fk=f(xk)
        absfk=sqrt(dot(fk.T,fk))
        if absfk<TOL or k>MAXITER:
            terminar=True
        else:
            sk=solve(Ak,-fk)
            xk1=xk+sk
            fk1=f(xk1)
            yk=fk1-fk
            Ak+=(1/dot(sk.T,sk))*(yk-Ak@sk)@sk.T
            k+=1
            fk=fk1
            xk=xk1
            print('iteracion',k)
            print(f'{xk[0][0]}{xk[1][0]}')
    print(f' metodo termino en {k} iteraciones, |f(x)|={absfk}')
    return xk                
from numpy import zeros_like,diag
def f(x):
    z=zeros_like(x)
    z[0]=x[0]-2*(x[1])**2 
    z[1]=x[1]-3*x[0]+5
    return z
x0=array([[0.0]]).T
A0=diag([1.0,1.0])
xk=broyden(x0,A0)       