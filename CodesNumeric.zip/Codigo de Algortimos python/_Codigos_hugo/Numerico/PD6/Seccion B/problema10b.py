import numpy as np
import scipy.linalg as sl
import sympy as sp
import sys
def krylow(A,e):
    #Calcula el polinomio(simbolico) caracteristico de la matriz A deorden n input
    #e: vector fila de nx1
    nrowA=np.shape(A)[0]
    B=np.zeros_like(A)
    colB=e
    B[:,nrowA-1]=colB.T
    print('row = {}:\in B = {}'.format(nrowA-1,B))
    for k in range(nrowA-2,-1,-1):
        colB=np.dot(A,colB)
        print("colB={}".format(colB))
        B[:,k]=colB.T
        print("row={}: \n B={}".format(k,B))
    c=(-1)*np.dot(A,colB)
    if np.isclose(sl.det(B),0.0):
        sys.exit("Matriz B singular, elegir otro vector e")
    a=sl.solve(B,c)
    x=sp.symbols('x') 
    return sp.Lambda(x,x**nrowA+sum(a[k]*x**(nrowA-k-1)for k in range(nrowA)))
A=np.array([[0.6,0.1,0.1],[0.1,0.8,0.2],[0.3,0.1,0.7]],float)
x=np.array([0.3,0.2,0.5]).reshape(3,1)
m=krylow(A,x)   
print(m)          