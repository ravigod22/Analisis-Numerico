import numpy as np
import math
def f(x):
    z=np.zeros_like(x)
    z[0]=x[0]**2+x[1]**2-290
    z[1]=x[0]-x[1]-24
   #Z[2]=x[0]+x[1]+x[2]-3 
    return z
def Broyden(x0,A0):
    TOL=1e-4
    Max_iter=100
    k=0
    xk=x0
    Ak=A0
    terminar=False
    while not terminar:
        fk=f(xk)
        absfk=np.sqrt(np.dot(fk.T,fk))
        if absfk < TOL or k>Max_iter:
            terminar=True
        else:
            sk=np.linalg.solve(Ak,-fk)
            xk1=xk+sk
            fk1=f(xk1)
            yk=fk1-fk
            Ak+=(1/np.dot(sk.T,sk))*(yk-Ak@sk)@sk.T
            k+=1
            fk=fk1
            xk=xk1
            print(f"{k:<8d}{xk[0][0]:<8.5f}") 
    print(f"Metodo terminar en {k} iteraciones, |f(x)|={absfk}")           
    return xk