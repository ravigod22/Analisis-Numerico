from scipy.interpolate import lagrange
import matplotlib.pyplot as plt
import numpy as np
def f(t):
    return 1/(1+t**2) 
#Variables
n=10
a=-5
b=5
x=np.linspace(a,b,n)
#Polinomio de Lgrange
p=lagrange(x,f(x))
print(p)
#Grafica
t=np.linspace(a,b,100)
plt.plot(t,f(t),label='x vs f')
plt.plot(t,p(t),label='x vs p')
plt.plot(x,p(x),'o')
plt.legend(loc=2)
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Polinomio de Lagrange p'+str(n-1))
plt.grid(True)
plt.show()    