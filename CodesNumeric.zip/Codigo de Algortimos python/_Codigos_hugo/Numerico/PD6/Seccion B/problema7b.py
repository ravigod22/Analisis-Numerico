import numpy as np
def Krylov(A,n):
    a=np.zeros(n)
    y0=np.array([1.0,0.0,0.0]).T
    y=[]
    y.append(y0)
    for i in range(n):
        y.append(np.dot(A,y[i]))
    for j in range(n):
        sum=0
        for k in range(j):
            sum+=y[n-k-1][n-j-1]*a[k]
        a[j]=(-(y[-1][n-j-1])-sum)/(y[n-j-1][n-j-1])
    return a 
M=np.array([[0.0,1.0,0.0],[1.0,0.0,1.0],[0.0,1.0,0.0]])
print(Krylov(M,3))              