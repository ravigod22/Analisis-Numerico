import numpy as np
from math import factorial
import sympy as sp
def leverrier_faddeev(A):
    #Calcula el polinomio caracteristico
    nrowA=np.shape(A)[0]
    b=np.zeros((0,0))
    B0=A
    b0=-np.trace(B0)
    print("b[{}]={}".format(1,b0))
    b=np.append(b,b0)
    for k in range(2,nrowA+1):
        B1= np.dot(A,B0+b0*np.identity(nrowA))
        b1= -np.trace(B1)/k
        b0= b1
        B0= B1
        b=np.append(b,b0)
        print("b[{}]={}".format(k,b0))
    x=sp.symbols('x')
    return sp.Lambda(x,x**nrowA+sum(b[k]*x**(nrowA-k-1)for k in range (nrowA)))
A=np.array([[0.6,0.1,0.1],[0.1,0.8,0.2],[0.3,0.1,0.7]])
m=leverrier_faddeev(A)
print(m)