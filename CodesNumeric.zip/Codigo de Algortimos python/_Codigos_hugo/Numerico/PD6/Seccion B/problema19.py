import numpy as np
from numpy.lib.arraysetops import setxor1d
from numpy.linalg.linalg import solve
def vandermonde(x):
    a=np.zeros((4,4))
    for i in range (0,4):
        a[:,i]=np.transpose([x[0]**i,x[1]**i,x[2]**i,x[3]**i])
    return a
x0=np.array([[0,5,10,15]]).T
A=vandermonde(x0)
b1=np.array([[72.8,74.2,75.2,76.4]]).T
b2=np.array([[70.23,70.2,70.3,71.2]]).T
S1=solve(A,b1)
S2=solve(A,b2)
print("Europa Oeste")
print(f'a0={S1[0,0]:<8.5f} a1={S1[1,0]:<8.5f} a2={S1[2,0]:<8.5f}')
print("Europa Este")
print(f'a0={S2[0,0]:<8.5f} a1={S2[1,0]:<8.5f} a2={S2[2,0]:<8.5f}')
f=lambda x:S1[0,0]+S1[1,0]*x**2+S1[3,0]*x**3
g=lambda x:S2[0,0]+S2[1,0]*x**2+S2[3,0]*x**3
print(f'Periodo\t 1977 \t\t 1983 \t\t 1989')
print(f'EUOeste\t {f(2):8.5f} \t{f(8):<8.5f}\t{f(14):8.5f}')
print(f'EUEste\t {g(2):8.5f} \t{g(8):<8.5f}\t{g(14):8.5f}')
f=lambda x:S1[0,0]+S1[1,0]*x**2+S1[3,0]*x**3
g=lambda x:S2[0,0]+S2[1,0]*x**2+S2[3,0]*x**3
