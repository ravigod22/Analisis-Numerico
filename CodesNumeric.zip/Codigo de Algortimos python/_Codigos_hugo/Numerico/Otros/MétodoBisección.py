'''Método para encontrar una raíz de una ecuación de la forma f(x)=0
Por ejemplo:    e^(-x)-x=0'''

'''Determinar gráficamente el número de raíces reales de la ecuación no lineal
    y resuelve usando el método de la Bisección para ε = 10^−5.
            e^(−x) − x = 0'''
import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.optimize as optimize


def maxIte(a, b, tol):                  #Devuelve el número máximo de iteraciones
    return math.ceil(math.log(abs(b - a) / tol, 2))


def biseccion(a, b, tol, max, c=None, i=1):
    c = (a + b) / 2
    if i > max:
        print("Parada por maxIteración")
        return c
    print('%.d' % i, '%8f' % a, '%.8f' % b, '%.8f' % c, '%.8f' % f(c))
    if f(c) == 0:
        return c #Raíz exacta
    if abs(b - a) / 2 >= tol:
        if f(a) * f(c) >= 0:
            a = c #Nuevo intervalo [c,b]
        elif f(a) * f(c) <= 0:
            b = c #Nuevo intervalo [a,c]
        c = biseccion(a, b, tol, max, c, i + 1)
    return c


def f(x):
    return np.exp(-x) - x
    #return x+np.exp(-1*x**2)*np.cos(x)

def c(x):
    return 0 * x


# Gráficamente
x = np.linspace(-10, 100, 100000)
plt.plot(x, f(x), label="f(x)=e^(-x)-x")
plt.plot(x, c(x), label="y=0")
plt.xlabel("Eje x")
plt.ylabel("Eje y")
plt.legend()
plt.grid()
plt.show()
# Método Bisección
maxI = maxIte(0, 1, 10 ** -5)
print("Máximas iteraciones: ", maxI)
print("i\t   a\t\tb\t\t\tc\t\tf(c):")
res = biseccion(0, 1, 10 ** -5, maxI)
print("La raíz es: ", res)
print("f(c) es: ", abs(f(res)))
print("\nPor la función optimize.bisect de python, c= ",optimize.bisect(f,0,1))


