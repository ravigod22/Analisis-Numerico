# Método de Newton-Raphson
# Ejemplo 1 (Burden ejemplo 1 p.51/pdf.61)
# JORGE LUIS CÁCERES NAUPARI

import numpy as np
import math
import matplotlib.pyplot as plt


def newton(B, x0):
    # Definir función
    #fx = lambda x: x + math.exp(-(B) * (x ** 2)) * math.cos(x)
    #dfx = lambda x: 1 - math.exp(-(B) * (x ** 2)) * (2 * (B) * x * math.cos(x) + math.sin(x))
    fx = lambda x: x**7-17.0859375
    dfx = lambda x: 7*(x**6)
    # Definir x0 si no se ingresa como entrada
    tolera = 0.0001 #e-10

    tabla = []  # Tabla para mostrar
    # Para graficar
    grafxi = []
    grafi = []
    error = abs(2 * tolera)  # Para que entre al bucle
    xi = x0
    cont = -1
    while error >= tolera:
        cont += 1
        if cont > 50:
            print("El método diverge, se alcanza el número máximo de iteraciones")
            break
        xnuevo = xi - fx(xi) / dfx(xi)
        error = abs(xnuevo - xi)
        tabla.append([cont, xi, xnuevo, fx(xi), dfx(xi), error])
        grafxi.append(xi)
        grafi.append(cont)
        xi = xnuevo

    # convierte la lista a un arreglo.
    tabla = np.array(tabla)
    grafxi = np.array(grafxi)
    grafi = np.array(grafi)
    n = len(tabla)
    # Graficando xn vs n
    plt.plot(grafi, grafxi, label='B={},x0={}'.format(B, x0))
    plt.xlabel("n")
    plt.ylabel("xn")
    plt.legend()
    plt.grid()
    # SALIDA
    print("Tabla B = ", B, ", x0 = ", x0)
    print(['i', 'xi', 'xnuevo', 'fx', 'dfx', 'error'])
    np.set_printoptions(precision=4)
    print(tabla)
    print('La raíz es: ', xi)
    print('con error de: ', error)
    print('f(raíz)= ', fx(xi))
    print()


def f(x, B):
    return x + np.exp(-B * x ** 2) * np.cos(x)


def graffx(B):
    # Graficar función
    x = np.linspace(-4, 4, 100000)
    plt.plot(x, f(x, B), label=("f(x)=x+e^(-{}*x^2)*cos(x)".format(B)))
    plt.xlabel("Eje x")
    plt.ylabel("Eje y")
    plt.legend()
    plt.grid()


graffx(1)
graffx(5)
graffx(10)
graffx(25)
graffx(50)
#plt.show()
# B=1,5,10,25,50
# x0=0,1,2,10
newton(1, 2)
'''newton(1, 0)
newton(1, 1)
newton(1, 2)
newton(1, 10)
plt.show()
newton(5, 0)
newton(5, 1)
newton(5, 2)
newton(5, 10)
plt.show()
newton(10, 0)
newton(10, 1)
newton(10, 2)
newton(10, 10)
plt.show()
newton(25, 0)
newton(25, 1)
newton(25, 2)
newton(25, 10)
plt.show()
newton(50, 0)
newton(50, 1)
newton(50, 2)
newton(50, 10)
plt.show()
newton(50, -0.1)
plt.show()*/

# newton(10,2)
# newton(25,10)'''
