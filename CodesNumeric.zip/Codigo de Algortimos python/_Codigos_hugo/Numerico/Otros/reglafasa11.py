#codigo de regla falsa
from numpy import sin
def regulafalsi(f,a,b):
    eps = 1E-5
    maxIter=100
    fa=f(a)
    fb=f(b)
    i=0
    while i<maxIter and b-a>=eps:
        c=a-fa*(b-a)/(fb-fa)
        fc=f(c)
        i+=1
        if fc==0:
            a=b=c
        elif fa*fb<0:
             b=c; fb=fc
        else:
            a=c; fa=fc
        print(f'[a,b]=[{a:5.2f},{b:5.2f}]')
    if b-a>=eps:
       print(f'Metodo no converge')
    else:
       print(f'Solucion c={c}')
       print(f'Numero de iteraciones={i}')
regulafalsi(f=lambda x: x*sin(x)-1,a=1,b=2)

