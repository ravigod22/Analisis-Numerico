import numpy as np
import matplotlib.pyplot as plt

def grafico_iteracionesVSx(gx, gy):
    plt.plot(gx, gy, 'r')
    plt.title('Método de Newton-Rahpson')
    plt.xlabel("Número de iteraciones")
    plt.ylabel("Valor de X")
    plt.show()

def metodo_newton_raphson(x, f, fd, maxIter, tol):
    n = 0
    while n < maxIter:
        y = x
        x = x - f(x)/fd(x)
        gy.append(x)
        n+=1
        gx.append(n)
        print("Para la iteracion "+str(n)+": X =" + str("{:10.10f}".format(x))+"\tError: "+str(abs(x-y)))
        if(abs(x-y) < tol):
            grafico_iteracionesVSx(gx, gy)
            return x
    print("\nEl método diverge o no converge para la cota de error pedido")

if __name__ == '__main__':
    print('MÉTODO NEWTON-RAPHSON', end="\n\n")
    gx = []
    gy = []
    def f(x): return x**3 - 3*x + 4
    def df(x): return 3*(x**2) - 3
    print("Tenemos la función f(x) = x^3 - 3x + 4\n")
    def b(x):
        return (x*0)
    x = np.linspace(-4, 4, 100)
    plt.plot(x, f(x),color='green')
    plt.plot(x, b(x),'red')
    plt.title('F(x) = x^3-x+4')
    plt.xlabel("x")
    plt.ylabel("F(x)")
    plt.show()
    Xo = float(input("Digite el valor inicial de X0 = "))
    gy.append(Xo)
    gx.append(0)
    #Número de iteraciones
    maxIter = int(input("Digite el número máximo de iteraciones: "))
    #Poner la cota de error de la raíz
    tol = float(input("Digite la tolerancia: "))

    x = metodo_newton_raphson(Xo, f, df, maxIter, tol)
    print("\nLa raíz buscada es: "+str(x))
