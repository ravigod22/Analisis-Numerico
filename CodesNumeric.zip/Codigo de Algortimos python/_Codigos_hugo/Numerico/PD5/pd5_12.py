import numpy as np
import math
import matplotlib.pyplot as plt


#====Funcion para encontrar el numero de raices de una funcion=======

def numeroDeRaices(A,B,F):  #Como parametro el intervalo a verifica
    
    print("Las solucion que se encuentra en ["+str(A)+";"+str(B)+"]")
    l = A
    k = 0
    soluciones = []
    
    a = A
    b = float(0)
    
    statusPosi = 0  #prendido 1 y apadado 0
    statusNega = 0  #prendido 1 y apadado 0
    while l <= B:
        
        if F(l) > 0:
            statusPosi = 1
            b = l
        if F(l)==0.0:
            print ("Solucion encontrada en inspeccion: "+str(l))
        if F(l) < 0:
            statusNega = 1
            b = l
        
        if statusPosi == 1 and statusNega == 1:
            k=k+1
            statusPosi = 0
            statusNega = 0
            soluciones.append([a,b])
            print(str(k)+"["+str(a)+";"+str(b)+"]")
        
        a = b

        l=l + 0.1 #Longitud para averiguar un interbalo
    print("_____________________________________________-")
    
    return soluciones




#====METODOS PARA ENCONTRAR LA SOLUCION DE ECUACIONES NO LINEALES=======


#1)METODO DE BISECCION
def metodoDeBiseccion(a,b,F):
    
    FA = F(a)
    FB = F(b)

    sol = 0.0
    numMaxInter = 100

    if FA*FB >= 0:
        print ("a="+str(a)+" b="+str(b)+" F(a)="+str(FA)+" F(b)="+str(FB))
        print("La funcion tienen igual signo en a y b")
        return

    else:

        for i in range(numMaxInter):
            erro = (b-a)/2
            c = a + erro   #c=(a+b)/2
            FC = F(c)

            if abs(erro) < 1E-5:  #TOL
                print("La solucion Converge para Epsilon dado")
                print("La solucion aproximada es: " + str(sol))
                break
            print(str(i+1).ljust(2)+"  "+str(a).ljust(30)+" "+str(b).ljust(30)+" "+str(c).ljust(30)+" "+str(FC).ljust(30))
            sol = c
            if FA*FC < 0:
                b = c
                FB = FC
            else:
                a = c
                FA = FC
        return


#2) METODO DE  LA SECANTE
def metSecante(p0,p1,F):
    print("Metos de la Secante")
    p0 = float(p0)
    p1 = float(p1)
    Fp0 = float(F(p0))
    Fp1 = float(F(p1))

    sol = 0.0
    eps = 1E-5
    
    numMaxInter = 100
    
    Xn = []
    Fn = []

    i = 1

    while i <= numMaxInter:
        h = -Fp1*(p1-p0)/(Fp1-Fp0)
        p0 = p1
        p1 = p1 + h
        Fp0 = Fp1
        Fp1 = F(p1)
        sol = p1
        
        Xn.append(i)
        Fn.append(p1)
        
        if abs(Fp1) < eps:  #TOL
            print("La solucion Converge")
            print("Numero de iteraciones: "+str(i))
            print("La solucion aproximada es: " + str(sol))
            
            result = [Xn,Fn]
            return result
        
        salida = "{0}:  [{1:.5f};{2:.5f}]"
        print(salida.format(i,p0,p1))
        i = i+1
    if abs(Fp1)>eps:
        print("Metodo no converge")
    result = [Xn,Fn]
    return result



#3)METODO DE FALSA POSICION
def metFalsaPosicion(p0,p1,F):
    print("Metos de Falsa Posicion")
    p0 = float(p0)
    p1 = float(p1)
    Fp0 = float(F(p0))
    Fp1 = float(F(p1))

    sol = 0.0
    eps = 1E-5
    
    numMaxInter = 100
    
    Xn = []
    Fn = []

    if Fp0*Fp1 >= 0:
        print ("a="+str(p0)+" b="+str(p1)+" F(a)="+str(Fp0)+" F(b)="+str(Fp1))
        print("La funcion tienen igual signo en a y b")
        return

    else:
        i = 1
        while i <= numMaxInter:
            p = p1-Fp1*(p1-p0)/(Fp1-Fp0)

            Xn.append(i)
            Fn.append(p)

            if abs(p-p1) < eps:  #TOL
                print("La solucion Converge")
                print("Numero de iteraciones: "+str(i))
                print("La solucion aproximada es: " + str(sol))
                
                result = [Xn,Fn]
                return result
                
            
            salida = "{0}:  [{1:.5f};{2:.5f}]"
            print(salida.format(i,p0,p1))
            sol = p
            Fp = F(p)
            
            if Fp*Fp1 < 0:
                p1 = p
                Fp1 = Fp
            else:
                p0 = p
                Fp0 = Fp
            i = i+1
        
        print("No converge")
        result = [Xn,Fn]
        return result


#4)METODO DE PUNTO FIJO
def metPuntoFijo(p0,g,f):
    p0 = float(p0)
    print("Metos del Punto fijo")
    sol = 0.0
    eps = 1E-5
    
    numMaxInter = 100
    
    Xn = []
    Fn = []

    i = 1

    while i <= numMaxInter:
        gp0 = g(p0)
        p = gp0
        sol = p
        
        Xn.append(i)
        Fn.append(p)
        
        salida = "x{0:2.0f} = {1:.5f}  f({2:.5f})={3:.5f}"
        
        print(salida.format(i,p0,p0,f(p)))
        if abs(p-p0) < eps:
            print("La solucion Converge")
            print("Numero de iteraciones: "+str(i))
            print("La solucion aproximada es: " + str(sol))
            
            result = [Xn,Fn]
            return result
            
            
        p0 = p
        i = i+1
        
    print("El metodo no converge")
    
    result = [Xn,Fn]
    return result

#5)METODO DE Steffenson
def metSteffenson(p0,f):
    print("Metos de Steffenson")
    p0 = float(p0)
    eps = 1E-5
    numMaxInter = 100
    
    Xn = []
    Fn = []
    
    i = 1
    
    while i <= numMaxInter:
        
        D = (f(p0+f(p0))-f(p0))/f(p0)
        
        p = p0 - f(p0)/D
        
        Xn.append(i)
        Fn.append(p)
        
        salida = "x{0:2.0f} = {1:.5f}  f({2:.5f})={3:.5f}"
        print(salida.format(i,p0,p0,f(p)))
        if abs(p-p0) < eps:
            print("Converge")
            print("Numero de iteraciones: "+str(i))
            print("Solucion: "+str(p))
            
            result = [Xn,Fn]
            return result
        i = i+1
        p0 = p
    print("El metodo no converge")
    result = [Xn,Fn]
    return result
    
        

#6)METODO DE HALLEY
def metHalley(p0,f,f1,f2):
    print("Metos de Halley")
    p0 = float(p0)
    eps = 1E-5
    numMaxInter = 100
    
    Xn = []
    Fn = []
    
    i = 1
    
    while i <= numMaxInter:
        
        
        M = math.pow(1-(f(p0)*f2(p0))/(2*math.pow(f1(p0),2)),-1)
        
        p = p0 - (f(p0)/f1(p0))*M
        
        Xn.append(i)
        Fn.append(p)
        
        salida = "x{0:2.0f} = {1:.5f}  f({2:.5f})={3:.5f}"
        print(salida.format(i,p0,p0,f(p)))
        if abs(p-p0) < eps:
            print("Converge")
            print("Numero de iteraciones: "+str(i))
            print("Solucion: "+str(p))
            result = [Xn,Fn]
            return result
        i = i+1
        p0 = p
    print("El metodo no converge")
    result = [Xn,Fn]
    return result

#===================================================================

#========definicion de la funcion a evaluar==========0



#Problema 12
#a)  math.pow(math.e)-2*math.pow(a,2)

#f = lambda a: math.pow(math.e,a)-2*math.pow(a,2)
#g = lambda a: math.sqrt(0.5*math.pow(math.e,a))
##g = lambda a: math.log(2*math.pow(a,2))
##g = lambda a:  math.pow(math.e,a)/(2*a)
#f1 = lambda a: math.pow(math.e,a)-4*a
#f2 = lambda a: math.pow(math.e,a)-4
#p0 = 1.2
#p1 = 1.6
#A = -5.0
#B = 5.0
#numeroDeRaices(A,B,f)
#print("----------------------------------------------------")
#re1 = metSecante(p0,p1,f)
#print("----------------------------------------------------")
#re2 = metFalsaPosicion(p0,p1,f)
#print("----------------------------------------------------")
#re3 = metPuntoFijo(p0,g,f)
#print("----------------------------------------------------")
#re4 = metSteffenson(p0,f)
#print("----------------------------------------------------")
#re5 = metHalley(p0,f,f1,f2)

#b)  

#f = lambda a: math.pow(a,3)-math.pow(a,2)-a-1
#g = lambda a: math.sqrt((1+a)/(a-1))
#f1 = lambda a: 3*math.pow(a,2)-2*a-1
#f2 = lambda a: 6*a-2
#p0 = 1.7
#p1 = 1.9
#A = -5.0
#B = 5.0
#numeroDeRaices(A,B,f)
#print("----------------------------------------------------")
#re1 = metSecante(p0,p1,f)
#print("----------------------------------------------------")
#re2 = metFalsaPosicion(p0,p1,f)
#print("----------------------------------------------------")
#re3 = metPuntoFijo(p0,g,f)
#print("----------------------------------------------------")
#re4 = metSteffenson(p0,f)
#print("----------------------------------------------------")
#re5 = metHalley(p0,f,f1,f2)

#c)  

f = lambda a: math.pow(math.e,a)-1/(0.1+math.pow(a,2))
g = lambda a: math.sqrt((1/math.pow(math.e,a))-0.1)
f1 = lambda a: math.pow(math.e,a)+2*a/(math.pow(0.1+math.pow(a,2),2))
f2 = lambda a: math.pow(math.e,a)+2*(-3*math.pow(a,2)+0.1)/(math.pow(0.1+math.pow(a,2),3))
p0 = 0.5
p1 = 0.7
A = -5.0
B = 5.0
numeroDeRaices(A,B,f)
print("----------------------------------------------------")
re1 = metSecante(p0,p1,f)
print("----------------------------------------------------")
re2 = metFalsaPosicion(p0,p1,f)
print("----------------------------------------------------")
re3 = metPuntoFijo(p0,g,f)
print("----------------------------------------------------")
re4 = metSteffenson(0.7,f)
print("----------------------------------------------------")
re5 = metHalley(p0,f,f1,f2)



#Graficando 

plt.plot(re1[0],re1[1],label = 'Secante')
plt.plot(re2[0],re2[1],label = 'Falsa Posicion')
plt.plot(re3[0],re3[1],label = 'Punto Fijo')
plt.plot(re4[0],re4[1],label = 'Steffenson')
plt.plot(re5[0],re5[1],label = 'Halley')
plt.ylabel("Valor de Xn")
plt.xlabel("numero de iteraciones n")

plt.legend(bbox_to_anchor=(1.05, 1.0), loc='upper left')
plt.tight_layout()

plt.grid()
plt.show()


























