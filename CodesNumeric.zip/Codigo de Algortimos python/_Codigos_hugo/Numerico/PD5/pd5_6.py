import numpy as np
f1= lambda x,y: x**2 + y**2 - 290
f2= lambda x,y: x+y-24
#Condicion inicial
x0=11
y0=10

dx= lambda x,y: (2*y*f2(x0,y0)-f1(x0,y0))/(2*(x-y))
dy= lambda x,y: (2*x*f2(x0,y0)-f1(x0,y0))/(2*(y-x))

dl=0.05 #Paso
x=[x0]; y=[y0]

cont=int((1/dl)+1) #numero de iteraciones

for i in range(1,cont):
    #aproximacion por diferenciales
    xx = x[i-1] + dl * dx(x[i-1],y[i-1])
    yy = y[i-1] + dl * dy(x[i-1],y[i-1])
    x += [xx]
    y += [yy]

x=np.array(x)
y=np.array(y)
print("Paso: ",dl)
for i in range(1,len(x)):
    dl2=dl*i
    print("Iteracion: ",i,"("+str("{:0.2f}".format(dl2))+")","\tx="+str(x[i])+"\ty="+str(y[i])+"\tError f1:"+str(f1(x[i],y[i]))+"\tError f2:"+str(f2(x[i],y[i])))
