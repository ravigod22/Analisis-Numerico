def f4(x,a):
    x= x*(x**2 + 3*a)/(3 * x**2 + a)
    return x

maxIter = 100
eps = 1e-5
a = 0.02
x0 = 5
f0 = f4(x0,a)
i = 0
while i<maxIter and abs(f0-x0)>=eps:
    x0=f0
    f0=f4(x0,a)
    i+=1
    print(f'x0= {x0:5.5f} f0: {f0:5.5f}')
if abs(f0-x0)>=eps:
    print("No converge")
else:
    print("Converge en: ",x0)
