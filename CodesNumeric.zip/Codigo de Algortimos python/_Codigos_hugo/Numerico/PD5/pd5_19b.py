def f2(x):
    x= 2*x/3 + 1/(x**2)
    return x

maxIter = 100
eps = 1e-5
x0 = 0.1
f0 = f2(x0)
i = 0
while i<maxIter and abs(f0-x0)>=eps:
    x0=f0
    f0=f2(x0)
    i+=1
    print(f'x0= {x0:5.5f} f0: {f0:5.5f}')
if abs(f0-x0)>=eps:
    print("No converge")
else:
    print("Converge en: ",x0)
