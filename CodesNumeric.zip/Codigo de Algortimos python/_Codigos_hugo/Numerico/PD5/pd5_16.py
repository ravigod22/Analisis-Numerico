import matplotlib.pyplot as plt
import math
import numpy as np

def f(x):
    return x+math.log(x)
    #return math.cos(x)+math.pow(math.sin(50*x),2)

def g(x):
    return (1/x)+1
    #return 50*math.sin(100*x)-math.sin(x)

def newton(x0,e,error,xlbl,ylbl):
    iteracion = 1
    aux = 1
    condicion = True

    print('\nSOLUCION: ')

    while condicion:
        if g(x0) == 0.0:
            print('No se puede dividir entre 0')
            break
        x1 = x0 - f(x0) / g(x0)
        xlbl.append(x1)
        ylbl.append(iteracion)
        print('Iteracion: {}, x = {}, f(x) = {} y error = {}'.format(iteracion, x1, f(x1), error))
        error=abs(x1-x0)
        x0 = x1
        iteracion = iteracion + 1

        if iteracion > maxIter:
            if error > e:
                aux = 0
            break
        
        if x1 ==0:
            aux = 0
            break

        condicion = abs(f(x1)) > e

    if aux == 1:
        print('\nLa raiz es: {}. Con error: {}'.format(x1, error))
        print("Luego de ", iteracion-1, " iteraciones\n")
    else:
        print('\nNo converge.')
    plt.plot(xlbl, ylbl, "r")
    plt.title("#xn vs n")
    plt.xlabel("xn")
    plt.ylabel("n")
    plt.show()

print('\n\nINGRESE LOS DATOS A CONTINUACION: ')
x0 = input('\nX0: ')
e = input('Precision: ')
maxIter = input('Máximo de iteraciones: ')

x0 = float(x0)
e = float(e)
maxIter = float(maxIter)

xlbl = []
ylbl = []

error = abs(2*e)

newton(x0,e,error,xlbl,ylbl)



