from math import copysign, hypot
import numpy as np
def givens_rotation(A):
    (num_rows, num_cols) = np.shape(A)
    Q = np.identity(num_rows)
    R = np.copy(A)
    (rows, cols) = np.tril_indices(num_rows, -1, num_cols)
    for (row, col) in zip(rows, cols):
        if R[row, col] != 0:
            (c, s) = _givens_rotation_matrix_entries(R[col, col], R[row, col])

            G = np.identity(num_rows)
            G[[col, row], [col, row]] = c
            G[row, col] = s
            G[col, row] = -s

            R = np.dot(G, R)
            Q = np.dot(Q, G.T)
            
    return (Q, R)
def _givens_rotation_matrix_entries(a, b):
    r = hypot(a, b)
    c = a/r
    s = -b/r
    return (c, s)
x=np.array([[6,5,0],[5,1,4],[0,4,3]],float)
q1,r1=givens_rotation(x)
print("\nQ\n")
print(q1.round(4))
print("\nR\n")
print(r1.round(4))
