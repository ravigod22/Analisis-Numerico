import numpy as np
from numpy import linalg as la

def mostrarIteracion(x_kk, k, e):
    print("x^({}) = ".format(k), 
          "[\t" + "\t".join("{:.15f}".format(x) for x in x_kk) + "\t]", "\t\t e = ", e)
    
def esDefPositiva(A):
    return np.all(np.linalg.eigvals(A) > 0)
def esSimetrica(A):
    return not (A != A.T).any()

def metGradConjugados(A, b):
    if not esDefPositiva(A) or not esSimetrica(A):
        print("=> No se puede usar el método")
        if esDefPositiva(A) and not esSimetrica(A):
            print("La matriz A es DEFINIDA POSITIVA pero NO es SIMETRICA")
        if not esDefPositiva(A) and esSimetrica(A):
            print("La matriz A NO es DEFINIDA POSITIVA pero SI es SIMETRICA")
        if not esDefPositiva(A) and not esSimetrica(A):
            print("La matriz A NO es DEFINIDA POSITIVA NI SIMETRICA")
    else:
        x_0 = np.zeros(len(A))   
        rho = np.zeros(10000)

        x =  x_0
        r = b 
        rho[0] = la.norm(r, ord=np.inf) ** 2
        k = 1
        TOL = 1e-3
        while np.sqrt(rho[k-1]) > TOL * la.norm(b, ord = np.inf) :
            if (k==1):
                p = r
            else:
                beta = rho[k-1] / rho[k-2]
                p = r + beta * p

            w = A @ p
            alpha = rho[k-1] / (p @ w)
            x = x + alpha * p
            r = r - alpha * w
            rho[k] = la.norm(r, ord=np.inf) ** 2

            mostrarIteracion(x,k,np.sqrt(rho[k-1]) / la.norm(b, ord = np.inf))

            k += 1


A = np.array([[4,1,2],
                [3,1,4],
                [5,1,3]])
b = np.array([40,53,51])


metGradConjugados(A,b)